import React, { Component } from 'react';
import { DaycaresList } from './components/DaycaresList.js';

class App extends Component {
  render() {
    return (
      <div>
        <DaycaresList /> 
      </div>
    )
  }
}

export default App;